# Vegeutopia
AOL Software Engineering

Niko Nugraha - 2440066834
Axcel Deon Davelin Syahputra - 2440096566
Julio Pramaitama - 2440012592
